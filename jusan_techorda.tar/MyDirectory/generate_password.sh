#!/bin/bash

if [ "$#" -ne 2 ]; then
    echo "Использование: $0 <длина_пароля> <имя_файла>"
    exit 1
fi

PASSWORD_LENGTH="$1"
OUTPUT_FILE="$2"

for i in {1..10}; do

    PASSWORD=$(tr -dc 'A-Za-z0-9_@#!%*?&' </dev/urandom | head -c "$PASSWORD_LENGTH")

    echo "$PASSWORD" >> "$OUTPUT_FILE"
done

echo "Пароли успешно сгенерированы и сохранены в $OUTPUT_FILE"
