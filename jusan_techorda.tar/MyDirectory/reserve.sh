#!/bin/bash

SOURCE_DIRS=("/path/to/dir1" "/path/to/dir2") # укажите пути к директориям для бэкапа

BACKUP_DIR="/path/to/backup" # укажите путь к директории для хранения резервных копий

DATE=$(date +"%Y-%m-%d")

for DIR in "${SOURCE_DIRS[@]}"; do
    DIR_NAME=$(basename "$DIR")
    tar -czf "${BACKUP_DIR}/${DIR_NAME}-${DATE}.tar.gz" -C "$(dirname "$DIR")" "$DIR_NAME"
done

echo "Резервное копирование завершено."
