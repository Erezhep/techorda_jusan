#!/bin/bash

KEYWORD = "file"

echo "Поиск файлов содержащих слово '$KEYWORD':"

grep -rl "$KEYWORD"
