#!/bin/bash

echo "Обновление списка доступных пакетов..."
sudo apt update

echo "Проверка наличия обновлений..."
UPDATES=$(apt list --upgradable 2>/dev/null | grep -v "Listing..." | wc -l)

if [ "$UPDATES" -eq 0 ]; then
    echo "Обновлений не найдено."
else
    echo "$UPDATES обновлений найдено."

    echo "Установка обновлений..."
    sudo apt upgrade -y

    echo "Обновление всех пакетов до последних версий..."
    sudo apt full-upgrade -y

    echo "Очистка кэша пакетов..."
    sudo apt autoremove -y
    sudo apt clean

    echo "Обновления установлены успешно."
fi
