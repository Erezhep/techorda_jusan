#!/bin/bash

FILE="$0"

wc -w < "$FILE"
